Please download MySQL Connector/J (mysql-connector-java-8.0.xx.jar) from:
https://dev.mysql.com/downloads/connector/j/

Place the downloaded JAR file into this `lib/` folder (or into WEB-INF/lib) before deploying.
